#!/bin/bash
set -euo pipefail

skill_dir="$(cd "$(dirname "$0")" && pwd)"
result_file="$(mktemp -t codex-nhi-result.XXXXXX)"
log_file="$(mktemp -t codex-nhi-log.XXXXXX)"
cleanup() { rm -f "$result_file" "$log_file"; }
trap cleanup EXIT

codex_bin="${CODEX_BIN:-$(command -v codex || true)}"
if [ -z "$codex_bin" ]; then
  codex_bin="/Users/k.starchak/.vscode/extensions/openai.chatgpt-26.715.61943-darwin-arm64/bin/macos-aarch64/codex"
fi
if [ ! -x "$codex_bin" ]; then
  echo "Codex executable was not found. Set CODEX_BIN or install the Codex VS Code extension." >&2
  exit 127
fi

if ! "$codex_bin" exec --ephemeral --skip-git-repo-check --sandbox read-only \
  --output-schema "$skill_dir/codex-nhi-decision-schema.json" \
  --output-last-message "$result_file" \
  'You are a local NHI worker. The structured NHI invocation is supplied in stdin. Assess only that task. Select decision_type and proposed_action only from its allowed_actions. Never claim to complete work you did not do. Return the required JSON decision.' \
  >"$log_file" 2>&1; then
  status=$?
  cat "$log_file" >&2
  exit "$status"
fi
if [ ! -s "$result_file" ]; then
  echo "Codex exited without a structured NHI decision." >&2
  cat "$log_file" >&2
  exit 1
fi
cat "$result_file"
