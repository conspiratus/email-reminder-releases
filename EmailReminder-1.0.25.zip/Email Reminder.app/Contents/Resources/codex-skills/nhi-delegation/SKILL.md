---
name: nhi-delegation
description: Send work to a named MAP colleague through the running macOS Email Reminder NHI Bridge. Use when the user says in Russian or English to hand over, delegate, pass, send, or assign a task to a colleague, especially phrases such as "передай Ване", "поручи Ване", or "delegate to Vanya".
---

Use the local Email Reminder NHI Bridge as the only route for creating delegations. Do not call MAP directly and do not use, request, log, or transmit a Google OAuth token.

## Workflow

1. Derive a short title, a concise summary, expected result, and priority from the user's request. Use priority `0` for low-impact work, `1` for normal work, `2` for high-impact work, and `3` for urgent, time-sensitive, or blocking work. If the requested outcome is materially ambiguous, ask one concise question before sending.
2. Ask the local Bridge for active members of the access group; it uses the app's configured default group when `--group-id` is omitted:

```bash
<skill-dir>/scripts/send_delegation.py --list-members
```

Match the requested person against `display_name`, `email`, or `username`. If the match is ambiguous or absent, ask the user rather than guessing.
3. Run:

```bash
<skill-dir>/scripts/send_delegation.py \
  --recipient '<exact display name, email, or username>' \
  --title '<title>' \
  --summary '<summary>' \
  --expected-result '<expected result>' \
  --priority '<0|1|2|3>'
```

4. Report that the request was sent through the local Bridge and include returned delegation/task IDs. Do not report or expose any token.

## Setup and safeguards

- The Email Reminder app must be running and connected to NHI.
- The app's default access group is normally `6`; it controls access to the delegation, not the person who receives it.
- Do not read or create `~/.codex/nhi-recipients.json`. The Bridge is the source of recipient data and returns the MAP `user_id` dynamically.
- The Bridge creates and stores the origin agent session automatically. When this workflow runs inside Codex VS Code, it records the current IDE thread so a self-delegated task can return to that same thread. Do not manufacture `origin_agent_session_id`.
