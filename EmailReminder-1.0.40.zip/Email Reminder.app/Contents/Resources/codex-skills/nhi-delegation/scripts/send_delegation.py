#!/usr/bin/env python3
"""Send an NHI delegation through the running Email Reminder local Bridge."""

import argparse
import json
import os
import subprocess
import urllib.error
import urllib.request
from typing import Optional

BRIDGE_SERVICE = "com.emailreminder.swift.nhi-bridge"
BRIDGE_ACCOUNT = "localhost-token"


def command_output(*args: str) -> str:
    result = subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or "command failed")
    return result.stdout.strip()


def bridge_port() -> int:
    pids = command_output("pgrep", "-f", "Email Reminder.app/Contents/MacOS/EmailReminderSwift").splitlines()
    for pid in pids:
        sockets = command_output("lsof", "-nP", "-a", "-p", pid, "-iTCP", "-sTCP:LISTEN", "-F", "n")
        for line in sockets.splitlines():
            if not line.startswith("n") or ":" not in line:
                continue
            candidate = line.rsplit(":", 1)[-1]
            if candidate.isdigit():
                return int(candidate)
    raise RuntimeError("Email Reminder NHI Bridge is not running")


def bridge_call(tool: str, payload: dict) -> dict:
    token = command_output("security", "find-generic-password", "-s", BRIDGE_SERVICE, "-a", BRIDGE_ACCOUNT, "-w")
    request = urllib.request.Request(
        f"http://127.0.0.1:{bridge_port()}/v1/tools/{tool}",
        data=json.dumps(payload).encode(),
        method="POST",
        headers={"Content-Type": "application/json", "X-NHI-Bridge-Token": token},
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read())["result"]


def group_members(group_id: Optional[int]) -> tuple[int, list[dict]]:
    response = bridge_call("nhi.list_group_members", {"group_id": group_id} if group_id else {})
    group = response.get("group") if isinstance(response, dict) else None
    members = response.get("members") if isinstance(response, dict) else None
    resolved_group_id = group.get("id") if isinstance(group, dict) else None
    if not isinstance(resolved_group_id, int) or resolved_group_id <= 0 or not isinstance(members, list):
        raise RuntimeError("Bridge returned an invalid group-members response")
    return resolved_group_id, members


def recipient_target(members: list[dict], recipient: str) -> dict:
    needle = recipient.strip().casefold()
    matches = []
    for member in members:
        if not isinstance(member, dict) or not isinstance(member.get("user_id"), int):
            continue
        labels = (member.get("display_name"), member.get("email"), member.get("username"))
        if needle and any(isinstance(label, str) and label.strip().casefold() == needle for label in labels):
            matches.append(member)
    if len(matches) == 1:
        return {"user_id": matches[0]["user_id"]}
    candidates = [{key: member.get(key) for key in ("user_id", "display_name", "email", "username")}
                  for member in members if isinstance(member, dict)]
    if len(matches) > 1:
        raise RuntimeError(f"Recipient '{recipient}' is ambiguous. Choose one of: {json.dumps(matches, ensure_ascii=False)}")
    raise RuntimeError(f"No exact MAP group member matches '{recipient}'. Available members: {json.dumps(candidates, ensure_ascii=False)}")


def origin_binding(
    claude_session_id: str = "",
    workspace: str = "",
    is_pycharm: bool = False,
) -> Optional[dict]:
    """Return an IDE session binding only when the host exposes one."""
    codex_thread_id = os.environ.get("CODEX_THREAD_ID", "").strip()
    claude_session_id = claude_session_id.strip() or os.environ.get("CLAUDE_SESSION_ID", "").strip()
    workspace = workspace.strip() or os.getcwd()
    if codex_thread_id:
        return {
            "provider": "codex_vscode" if os.environ.get("VSCODE_PID") else "codex_desktop",
            "external_conversation_id": codex_thread_id,
            "workspace": workspace,
        }
    if claude_session_id:
        return {
            "provider": claude_provider(is_pycharm),
            "external_conversation_id": claude_session_id,
            "workspace": workspace,
        }
    return None


def claude_provider(is_pycharm: bool = False) -> str:
    """Identify the IDE hosting the Claude CLI session when it exposes one."""
    terminal_emulator = os.environ.get("TERMINAL_EMULATOR", "")
    if is_pycharm or os.environ.get("PYCHARM_HOSTED") or terminal_emulator.startswith("JetBrains"):
        return "pycharm_claude_cli"
    return "claude_vscode"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--list-members", action="store_true", help="Print members of the selected/default MAP access group")
    parser.add_argument("--group-id", type=int, help="MAP access group ID; omit to use the application's default")
    parser.add_argument("--recipient")
    parser.add_argument("--title")
    parser.add_argument("--summary")
    parser.add_argument("--expected-result")
    parser.add_argument("--priority", type=int, choices=range(4), default=1, help="0 low, 1 normal, 2 high, 3 urgent; defaults to normal")
    parser.add_argument("--claude-session-id", default="", help="Current Claude Code session UUID when it is not exposed through CLAUDE_SESSION_ID")
    parser.add_argument("--workspace", default="", help="Project workspace for an IDE handoff; defaults to the current directory")
    parser.add_argument("--pycharm", action="store_true", help="Mark the current Claude session as running in PyCharm")
    args = parser.parse_args()

    try:
        access_group_id, members = group_members(args.group_id)
        if args.list_members:
            print(json.dumps({"group_id": access_group_id, "members": members}, ensure_ascii=False))
            return
        if not all((args.recipient, args.title, args.summary, args.expected_result)):
            raise RuntimeError("--recipient, --title, --summary, and --expected-result are required when creating a delegation")
        payload = {
            "title": args.title,
            "summary": args.summary,
            "expected_result": args.expected_result,
            "priority": args.priority,
            "access_group_ids": [access_group_id],
            "assignees": [recipient_target(members, args.recipient)],
        }
        if args.pycharm and not (args.claude_session_id.strip() or os.environ.get("CLAUDE_SESSION_ID", "").strip()):
            raise RuntimeError("--pycharm requires --claude-session-id or CLAUDE_SESSION_ID so the task can resume the current Claude session")
        origin = origin_binding(args.claude_session_id, args.workspace, args.pycharm)
        if origin:
            payload["origin"] = origin
        print(json.dumps(bridge_call("nhi.create_delegation", payload), ensure_ascii=False))
    except (OSError, RuntimeError, ValueError, urllib.error.URLError, urllib.error.HTTPError) as error:
        if isinstance(error, urllib.error.HTTPError):
            raise SystemExit(f"Bridge request failed: {error.read().decode(errors='replace')}")
        raise SystemExit(str(error))


if __name__ == "__main__":
    main()
